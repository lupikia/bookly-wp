<?php
/**
 * Element Name: Map
 *
 * @author pebas
 * @version 1.0.0
 * @package pages/search-elements
 */
?>
<div id="map-search" class="map-search"></div>
