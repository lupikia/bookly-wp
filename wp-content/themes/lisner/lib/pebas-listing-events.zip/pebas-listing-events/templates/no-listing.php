<?php
/**
 * No Listing template
 *
 * @author includes
 * @version 1.0.0
 * @package templates
 */
?>
<div class="lisner-listing-table">
	<div class="lisner-listing-table-header mb-0">
		<p class="mb-0"><?php esc_html_e( 'Wrong listing, please make sure that you are on correct listing.', 'pebas-listing-events' ); ?></p>
	</div>
