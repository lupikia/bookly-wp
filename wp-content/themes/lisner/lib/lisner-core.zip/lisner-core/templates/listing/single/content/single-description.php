<?php
/**
 * Template Name: Listing Single Description
 * Description: Partial content for single listing content
 *
 * @author pebas
 * @version 1.0.0
 * @package listing/single/content
 */

?>
<!-- Single Listing / Description -->
<div class="single-listing-main-description">
	<?php wpjm_the_job_description(); ?>
</div>
