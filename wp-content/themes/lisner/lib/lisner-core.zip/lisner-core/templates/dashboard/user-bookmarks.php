<?php do_action( 'lisner_user_bookmarks_before' ); ?>
<?php do_action( 'lisner_user_bookmarks' ); ?>
<?php do_action( 'lisner_user_bookmarks_after' ); ?>
